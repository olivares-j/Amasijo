import numpy as np
import matplotlib.pyplot as plt

from pygaia.errors.photometric import magnitude_uncertainty


# Magnitude ranges
G = np.linspace(5, 21, 500)
BP = np.linspace(5, 21, 500)
RP = np.linspace(5, 21, 500)

# PyGaia DR3 uncertainties
sigma_G = np.sqrt(magnitude_uncertainty("g", G, release="dr3")**2 + 2.7553202**2)
sigma_BP = np.sqrt(magnitude_uncertainty("bp", BP, release="dr3")**2 + 2.7901700**2)
sigma_RP = np.sqrt(magnitude_uncertainty("rp", RP, release="dr3")**2 + 3.7793818**2)


# Plot
fig, ax = plt.subplots(figsize=(8, 6))

ax.plot(G, sigma_G, label=r"$G$")
ax.plot(BP, sigma_BP, label=r"$G_{\rm BP}$")
ax.plot(RP, sigma_RP, label=r"$G_{\rm RP}$")

ax.set_yscale("log")

ax.set_xlabel(r"Apparent magnitude [mag]")
ax.set_ylabel(r"Photometric uncertainty [mmag]")

ax.set_xlim(5, 21)
ax.grid(True, which="both", alpha=0.3)
ax.legend()

plt.tight_layout()
plt.show()