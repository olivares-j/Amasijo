import sys
import os
import dill
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import seaborn as sns
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, PowerTransformer
from mlp_model import create_custom_model


os.environ['CUDA_VISIBLE_DEVICES'] = '1'

train = False

# ------------------------------ Model properties --------------------------------
max_label = 1
features = ["age","Mini"]
targets  = ['Gmag', 'G_BPmag', 'G_RPmag']#, 'gP1mag', 'rP1mag', 'iP1mag','zP1mag','yP1mag','Jmag', 'Hmag', 'Ksmag']
list_of_num_layers = [3] # Number of hidden layers
list_of_size_layers = [700,800,900,1000,1100,1200,1300,1400,1500,1600,1700]  # Units in each hidden layer
training_epochs = [int(1e4),int(1e4),int(1e4),int(2e4)]
learning_rates  = [1e-3,1e-4,1e-5,1e-6]
activation_layers = "relu" # Activation functions for each hidden layer
output_activation = "linear"  # Activation function for the output layer
batch_fraction = 1.0
#--------------------------------------------------------------------------

#--------------- Directories and files ---------------------------------------------
dir_base  = "/home/jolivares/Models/PARSEC/Gaia_EDR3/50-150Myr/"
# Remove the # from the row contain the header in the input file
file_iso  = dir_base + "output.dat" 
dir_mlps  = dir_base + "MLPs/"

file_mad  = dir_mlps +"Phot_MAD.png"
base_fld  = "Phot_l{0}_s{1}/"
base_dat  = "{0}data.csv"
base_mlp  = "{0}mlp.pkl"
base_lss  = "{0}loss.png"
base_fit  = "{0}fit.png"
base_err  = "{0}error.png"
#------------------------------------------------------------------------------------

#------------- Load data ----------------------------
df_iso = pd.read_csv(file_iso,
					skiprows=13,
					delimiter=r"\s+",
					header="infer",
					comment="#")
df_iso = df_iso.loc[df_iso["label"]<= max_label]
df_iso["age"] = np.round(np.pow(10.,df_iso["logAge"])/np.pow(10.,6.0),decimals=1)
df_iso["Teff"] = np.pow(10.,df_iso["logTe"])
df_iso["Mini"] = np.round(df_iso["Mini"],decimals=3)
df_iso = df_iso.loc[:,sum([features,targets],[])]
print(df_iso.describe())
#----------------------------------------------------

#---------------------------------------- Select Masses to have uniform sampling -----------------------------------------------------------------
# For 50-150 Myr
# list_of_masses = np.array([0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0,2.2,2.4,2.6,2.8,3.0,3.2,3.4,3.6,3.8,4.0])
# df_iso = df_iso.query("Mini in @list_of_masses | Mini > 4.0")
#For 100-500 Myr
# list_of_masses = np.array([0.09,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,1.9,2.0])
# df_iso = df_iso.query("Mini in @list_of_masses | Mini > 2.0")
print(df_iso.describe())
df_iso = df_iso.query("Mini > 4.0")
#------------------------------------------------------------------------------------------------------------------------------------------------------------

mads = []
for size_layers in list_of_size_layers:
	for num_layers in list_of_num_layers:
		dir_case   = dir_mlps  + base_fld.format(num_layers,size_layers)
		os.makedirs(dir_case,exist_ok=True)

		file_mlp = base_mlp.format(dir_case)

		#------------------ Train ---------------------------
		if train:
			#-------------- Save data -------------- 
			df_iso.to_csv(base_dat.format(dir_case))
			#---------------------------------------

			#---------- Numpy arrays ------------------
			raw_features = df_iso[features].to_numpy()
			raw_targets  = df_iso[targets].to_numpy()
			#-------------------------------------------

			#---------------- Transformations ------------------------
			BoxCox = PowerTransformer(
						method="box-cox", 
						standardize=False).fit(raw_features)
			inputs = BoxCox.transform(raw_features)
			MinMax = MinMaxScaler().fit(inputs)
			scalers = [BoxCox, MinMax]
			#---------------------------------------------------------

			#------------ Domains ---------------------------------------------
			phot_min = df_iso[targets].min()
			age_domain = [df_iso["age"].min(),df_iso["age"].max()]
			mass_domain = [df_iso["Mini"].min(),df_iso["Mini"].max()]
			# teff_domain = [df_iso["Teff"].min(),df_iso["Teff"].max()]
			#-------------------------------------------------------------------------

			batch_size   = int(batch_fraction*df_iso.shape[0])
			transformed_features = scalers[1].transform(scalers[0].transform(raw_features))

			losses = []
			for learning_rate,epochs in zip(learning_rates,training_epochs):

				#--------------- Instantiate model -----------------------
				model = create_custom_model(
				input_shape=len(features), 
				num_layers=num_layers,
				size_layers=size_layers, 
				activation_layers=activation_layers, 
				output_units=len(targets), 
				output_activation=output_activation,
				learning_rate=learning_rate)
				#------------------------------------------------------------

				#------------ Load previous fit --------
				if os.path.isfile(file_mlp):
					with open(file_mlp, "rb") as file:
						mlp = dill.load(file)
						model.set_weights(mlp["weights"])
				#-----------------------------------------

				#------------ Fit -----------
				fit = model.fit(
					transformed_features,
					raw_targets,
					epochs=epochs,
					batch_size=batch_size,
					verbose=0)
				#----------------------------

				#--------- Save --------------------
				mlp = {
					"num_layers":num_layers,
					"size_layers":size_layers,
					"scalers":scalers,
					"weights":model.get_weights(),
					"phot_min":phot_min,
					"targets":targets,
					"age_domain":age_domain,
					"mass_domain":mass_domain,
					}

				with open(file_mlp, "wb") as file:
					dill.dump(mlp, file)
				#------------------------------------

				#------------- Data for loss plot ----------
				losses.append(fit.history["loss"])
				#---------------------------------------------

			loss = np.concatenate(losses,axis=0)
			df = pd.DataFrame(data={
						"loss":loss,
						"iter":np.arange(len(loss)),
						})

			#------------ Plot Loss --------------------------
			fig, ax = plt.subplots(1, 1, figsize=(16, 8))
			ax = sns.lineplot(data=df,
								x="iter",
								y="loss",
								zorder=0)
			ax.set_xlabel("Iteration")
			ax.set_ylabel("Loss")
			ax.set_yscale('log')
			fig.savefig(base_lss.format(dir_case))
			plt.close()

		#---------- Instantiate model ---------------------
		model = create_custom_model(
				input_shape=len(features), 
				num_layers=num_layers,
				size_layers=size_layers, 
				activation_layers=activation_layers, 
				output_units=len(targets), 
				output_activation=output_activation)
		#------------------------------------------------

		#------------ Load existing fit --------
		with open(file_mlp, "rb") as file:
			mlp = dill.load(file)
			scalers = mlp["scalers"]
			model.set_weights(mlp["weights"])
		#----------------------------------------

		#-------------- Plot predictions ---------------------
		df_tst = df_iso.copy()
		df_tst.reset_index(drop=True,inplace=True)

		df_features = df_tst[features]
		input_tst = scalers[1].transform(scalers[0].transform(df_features.to_numpy()))
		ouput_tst = model(input_tst,training=False)

		df_bands = pd.DataFrame(columns=targets,data=ouput_tst._numpy())
		df_prd = pd.concat([df_features,df_bands],axis=1,ignore_index=False)

		df = pd.merge(left=df_tst,right=df_bands,left_index=True,right_index=True,suffixes=["_tst","_prd"])
		df.set_index(features,drop=True,inplace=True)

		for trgt in targets:
			df[trgt] = df.apply(lambda x: (x[trgt+"_prd"]-x[trgt+"_tst"]),axis=1)

		#--------- Save for general plot---------------------
		tmp = pd.DataFrame(data={
			"MAD":df.loc[:,targets].abs().max().to_numpy().max(),
			"mean":df.loc[:,"Gmag"].abs().mean(),
			"std":df.loc[:,"Gmag"].std(),
			"num_layers":num_layers,
			"size_layers":size_layers},index=[0])
		tmp.set_index("num_layers",inplace=True)
		mads.append(tmp)
		#----------------------------------------------------

		df = df.loc[:,targets].stack().reset_index()
		df.columns = ["age","Mini","target","value"]
		print(df.describe())

		fig, ax = plt.subplots(1, 1, figsize=(16, 8))
		ax = sns.scatterplot(data=df,
							x="Mini",
							y="value",
							hue="age",
							style="target",
							zorder=0)
		ax.set_xlabel("Mini [Msun]")
		ax.set_ylabel("(Predicted-Test)")
		plt.legend(bbox_to_anchor=(1.01, 0.5), loc="center left")
		fig.savefig(base_err.format(dir_case))
		plt.close()

		ax = sns.scatterplot(data=df_tst,
				x="Mini",
				y="Gmag",
				hue="age",
				zorder=0)
		ax = sns.lineplot(data=df_prd,
				x="Mini",
				y="Gmag",
				hue="age",
				legend=False,
				sort=False,
				zorder=1,
				ax=ax)
		ax.set_xlabel("Mini [Msun]")
		ax.set_ylabel("G [mag]")
		plt.savefig(base_fit.format(dir_case))
		plt.close()

df_mad = pd.concat(mads,ignore_index=False)
fig, ax = plt.subplots(1, 1, figsize=(16, 8))
ax = sns.scatterplot(data=df_mad,
					hue="num_layers",
					y="mean",
					x="size_layers",
					zorder=0)
ax.errorbar(
	x=df_mad["size_layers"],
	y=df_mad["mean"],
	yerr=df_mad["std"],
	color='tab:blue',
	ecolor='tab:grey')
ax.set_xlabel("Size of layers")
ax.set_ylabel("Mean error")
ax.xaxis.set_major_locator(MaxNLocator(integer=True))
plt.legend(bbox_to_anchor=(1.01, 0.5), loc="center left")
fig.savefig(file_mad)
plt.close()